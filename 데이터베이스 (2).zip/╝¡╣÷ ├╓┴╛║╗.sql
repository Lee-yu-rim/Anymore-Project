CREATE TABLE reservation (
   num   number(10,0)      NOT NULL,
   title   varchar2(50)      NOT NULL,
   sex   varchar2(10)      NULL,
   people_cnt   varchar2(30)      NOT NULL,
   visiter_name   varchar2(20)      NOT NULL,
   phone   varchar2(30)      NOT NULL,
   visit_day   date      NOT NULL,
   reser_time   varchar2(30)      NOT NULL,
   visit_reason   varchar2(2000)      NULL,
   id   varchar2(20)      NULL,
   visit_identify   number(10,0)      NOT NULL
);

COMMENT ON COLUMN reservation.visit_identify IS '1�̸� �ܼ��湮, 2�̸� ����湮';

CREATE TABLE zzim (
	id	varchar2(20)		NOT NULL,
	board_num	number(10,0)		NULL
);

CREATE TABLE free_board_reply (
	rno	number(10,0)		NOT NULL,
	reply	varchar2(500)		NOT NULL,
	bno	number(10,0)		NOT NULL,
	id	varchar2(30)		NOT NULL,
	replydate	date	DEFAULT sysdate	NOT NULL,
	updatedate	date	DEFAULT sysdate	NOT NULL
);

CREATE TABLE adopt_reservation (
	adoptnum	number(10,0)		NOT NULL,
	name	varchar2(50)		NOT NULL,
	phone	varchar2(20)		NOT NULL,
	birthday_date	varchar2(200)	NOT NULL,
	address	varchar2(200)		NOT NULL,
	board_num	number(10,0)		NULL,
	servey1	varchar2(500)		NOT NULL,
	servey2	varchar2(500)		NOT NULL,
	servey3	varchar2(500)		NOT NULL,
	servey4	varchar2(500)		NOT NULL,
	servey5	varchar2(500)		NOT NULL,
	servey6	varchar2(500)		NOT NULL,
	servey7	varchar2(500)		NOT NULL,
	servey8	varchar2(500)		NOT NULL,
    reg_date date default sysdate not null,
    id	varchar2(20)		NOT NULL
);

CREATE TABLE free_board (
   bno   number(10,0)      NOT NULL,
   title   varchar2(50)      NOT NULL,
   content   varchar2(2000)      NOT NULL,
   regdate   date   DEFAULT sysdate   NULL,
   updatedate   date   DEFAULT sysdate   NULL,
   reply_cnt   number(10,0)      NULL,
   visit_cnt   number(10,0)      NULL,
   field   varchar2(20)      NOT NULL,
   id   varchar2(20)      NOT NULL
);

COMMENT ON COLUMN free_board.field IS '0~4���� �ؼ�
0: �� �ݷ����� �ڶ�
1: ��ᰣ����õ
2: ���������ı�
3: ���� �����ϱ�
4: ��åȸ';

CREATE TABLE anymore_product (
	product_num	number(10,0)		NOT NULL,
	price	varchar2(50)		NOT NULL,
	discribe	varchar2(2000)		NOT NULL,
    p_amount number(10,0) NULL,
	product_name	varchar2(500)		NOT NULL,
	product_regdate	date	DEFAULT sysdate	NOT NULL,
	product_content	varchar(2000)		NOT NULL
);

CREATE TABLE product_perchase (
	perchase_num	number(10,0)		NOT NULL,
	name	varchar2(50)		NOT NULL,
	perchased_product	varchar2(500)		NOT NULL,
	all_price	varchar2(500)		NOT NULL,
	ordered_date	date	DEFAULT sysdate 	NOT NULL,
	delivery_status	varchar2(50)		NOT NULL,
	product_num	number(10,0)		 NULL,
	payment	varchar2(50)		NOT NULL,
	id	varchar2(20)		NOT NULL
);

CREATE TABLE perchase_info (
	perchase_num	number(10,0)		NOT NULL,
	perchased_pname	varchar2(50)		NOT NULL,
	amount	number(10,0)		NOT NULL,
	product_price	number(10,0)		NOT NULL
);

CREATE TABLE delivery_info (
	perchase_num	number(10,0)		NOT NULL,
	name	varchar2(50)		NOT NULL,
	address	varchar2(100)		NOT NULL,
	phone	varchar2(50)		NOT NULL,
	requests	varchar2(200)		NULL
);

CREATE TABLE animal_info (
	board_num	number(10,0)		NOT NULL,
	animal_name	varchar2(50)		NOT NULL,
	enter_day	date	DEFAULT sysdate 	NOT NULL,
	protect_day	date	DEFAULT sysdate 	NOT NULL,
	variety	varchar2(50)		NOT NULL,
	age	varchar2(50)		NOT NULL,
	sex	varchar2(20)		NOT NULL,
	tnr	varchar2(20)		NOT NULL,
	identity	varchar2(500)		NOT NULL,
	euthanasia_day	varchar2(50)		NOT NULL
);

CREATE TABLE animal_fileupload (
	fno	number(10,0)		NOT NULL,
	fileName	varchar2(100)		NOT NULL,
	uuid	varchar2(100)		NOT NULL,
	uploaddate	date		NOT NULL,
	file_size	number(20,0)		NULL,
	board_num	number(10,0)		NOT NULL,
    uploadpath 	varchar2(200)		NOT NULL,
	fileType	char(1)		NULL
    
);


CREATE TABLE member (
	id	varchar2(20)		NOT NULL,
	password	varchar2(20)		NOT NULL,
	name	varchar2(10)		NOT NULL,
	staffs	varchar2(2)	DEFAULT 'n'	NOT NULL,
	phone	varchar2(20)		NOT NULL,
	birth	varchar2(20)		NOT NULL,
	email	varchar2(50)		NOT NULL,
	pass_question	number(2, 0)	DEFAULT 1	NULL,
	pass_answer	varchar2(100)		NULL,
	address	varchar2(100)		NOT NULL,
	regdate	date	DEFAULT sysdate	NOT NULL,
	alert_cnt	number(10, 0)		NULL,
    member_num  	number(10,0)	NOT NULL,
    kakao_email     varchar2(50) null
);

COMMENT ON COLUMN member.staffs IS 'y : ������ / n : �Ϲ� ȸ��';

COMMENT ON COLUMN member.pass_question IS '1 : ����1 ~ 5: ����5';

CREATE TABLE cart (
	c_num	number(10,0)		NOT NULL,
	quantity	number(10,0)		NOT NULL,
	c_regdate	date	DEFAULT sysdate	NOT NULL,
	id	varchar2(20)		NOT NULL,
	product_num	number(10,0)		NOT NULL
);



CREATE TABLE used_items (
   bno   number(10, 0)      NOT NULL,
   title   varchar2(30)      NOT NULL,
   content   varchar2(1000)      NOT NULL,
   regdate   date   DEFAULT sysdate   NOT NULL,
   updatedate   date   DEFAULT sysdate   NOT NULL,
   reply_cnt   number(10, 0)      NOT NULL,
   visit_cnt   number(10, 0)      NOT NULL,
   field   varchar2(20)      NOT NULL,
   id   varchar2(20)      NOT NULL,
   deal varchar2(20)    null
);

COMMENT ON COLUMN used_items.field IS '0:�˴ϴ� 1:��ϴ� 2:�ı�';

CREATE TABLE used_items_reply (
	rno	number(10,0)		NOT NULL,
	reply	varchar2(500)		NOT NULL,
	bno	number(10, 0)		NOT NULL,
	id	varchar2(30)		NOT NULL,
	replydate	date	DEFAULT sysdate	NOT NULL,
	updatedate	date	DEFAULT sysdate	NOT NULL
);

CREATE TABLE adoption_review (
	bno	number(10,0)		NOT NULL,
	title	varchar2(30)		NOT NULL,
	content	varchar2(1000)		NOT NULL,
	regdate	date	DEFAULT sysdate	NOT NULL,
	updatedate	date	DEFAULT sysdate	NOT NULL,
	reply_cnt	number(10,0)		NOT NULL,
	visit_cnt	number(10,0)		NOT NULL,
	id	varchar2(20)		NOT NULL
);

CREATE TABLE adoption_reply (
	rno	number(10,0)		NOT NULL,
	reply	varchar2(500)		NOT NULL,
	bno	number(10,0)		NOT NULL,
	id	varchar2(30)		NOT NULL,
	replydate	date	DEFAULT sysdate	NOT NULL,
	updatedate	date	DEFAULT sysdate	NOT NULL
);

CREATE TABLE commu_fileupload (
	fno	number(10,0)		NOT NULL,
	fileName	varchar2(100)		NOT NULL,
	uuid	varchar2(100)		NOT NULL,
	uploaddate	date		NOT NULL,
	file_size	number(20,0)		NULL,
	bno	number(10,0)		NOT NULL,
    uploadpath 	varchar2(200)		NOT NULL,
	fileType	char(1)		NULL
);

CREATE TABLE QNA_reply (
	bno	number(10,0)		NOT NULL,
	rno	number(10,0)		NOT NULL,
	reply	varchar2(1000)		NOT NULL,
	replydate	date	DEFAULT sysdate	NOT NULL,
	updatedate	date	DEFAULT sysdate	NOT NULL,
	id	varchar2(20)		NOT NULL
);



CREATE TABLE qna_fileupload (
	fno	number(10,0)		NOT NULL,
	bno	number(10,0)		NOT NULL,
	filename	varchar2(100)		NOT NULL,
	uuid	varchar2(100)		NOT NULL,
	uploaddate	date		NOT NULL,
	file_size	number(20,0)		NULL,
    uploadpath 	varchar2(200)		NOT NULL,
	fileType	char(1)		NULL
);

CREATE TABLE QNA (
	bno	number(10,0)		NOT NULL,
	title	varchar2(100)		NOT NULL,
	content	varchar2(3000)		NOT NULL,
	id	varchar2(30)		NOT NULL,
	regdate	date	DEFAULT sysdate	NOT NULL,
	updatedate	date	DEFAULT sysdate	NOT NULL,
	count	number(10,0)		NOT NULL,
    replycnt number(10,0)  default 0  null 
);


CREATE TABLE notice (
	bno	number(10,0)		NOT NULL,
	title	varchar2(100)		NOT NULL,
	content	varchar2(3000)		NOT NULL,
	id	varchar2(30)		NOT NULL,
	regdate	date	DEFAULT sysdate	NOT NULL,
	updatedate	date	DEFAULT sysdate	NOT NULL,
	count	number(10,0)		NOT NULL
);

CREATE TABLE FAQ (
	bno	number(10,0)		NOT NULL,
	title	varchar2(100)		NOT NULL,
	content	varchar2(3000)		NOT NULL,
	id	varchar2(30)		NOT NULL,
	regdate	date	DEFAULT sysdate	NOT NULL,
	updatedate	date	DEFAULT sysdate	NOT NULL,
	count	number(10,0)		NOT NULL
);

CREATE TABLE notice_fileupload (
	fno	number(10,0)		NOT NULL,
	bno	number(10,0)		NOT NULL,
	fileName	varchar2(100)		NOT NULL, 
	uuid	varchar2(100)		NOT NULL,
	uploaddate	date		NOT NULL,
	file_size	number(20,0)		NULL,
    uploadpath 	varchar2(200)		NOT NULL,
	fileType	char(1)		NULL
);

CREATE TABLE faq_fileupload (
	fno	number(10,0)		NOT NULL,
	bno	number(10,0)		NOT NULL,
	fileName	varchar2(100)		NOT NULL,
	uuid	varchar2(100)		NOT NULL,
	uploaddate	date		NOT NULL,
	file_size	number(20,0)		NULL,
    uploadpath 	varchar2(200)		NOT NULL,
	fileType	char(1)		NULL
);

CREATE TABLE used_item_file_upload (
	fno	number(10,0)		NOT NULL,
	fileName	varchar2(100)		NOT NULL,
	uuid	varchar2(100)		NOT NULL,
	uploaddate	date		NOT NULL,
	file_size	number(20,0)		NULL,
	bno	number(10, 0)		NOT NULL,
    uploadpath 	varchar2(200)		NOT NULL,
	fileType	char(1)		NULL
);

CREATE TABLE anymore_fileupload (
	fno	number(10,0)		NOT NULL,
	fileName	varchar2(100)		NOT NULL,
	uuid	varchar2(100)		NOT NULL,
	uploaddate	date		NOT NULL,
	file_size	number(20,0)		NULL,
	product_num	number(10,0)		NOT NULL,
    uploadpath 	varchar2(200)		NOT NULL,
	fileType	char(1)		NULL
);

CREATE TABLE adopt_fileupload (
	fno	number(10,0)		NOT NULL,
	fileName	varchar2(100)		NOT NULL,
	uuid	varchar2(100)		NOT NULL,
	uploaddate	date		NOT NULL,
	file_size	number(20,0)		NULL,
	bno	number(10,0)		NOT NULL,
    uploadpath 	varchar2(200)		NOT NULL,
	fileType	char(1)		NULL
);

ALTER TABLE reservation ADD CONSTRAINT PK_RESERVATION2 PRIMARY KEY (
   num
);

ALTER TABLE free_board ADD CONSTRAINT PK_FREE_BOARD PRIMARY KEY (
	bno
);

ALTER TABLE anymore_product ADD CONSTRAINT PK_ANYMORE_PRODUCT PRIMARY KEY (
	product_num
);

ALTER TABLE product_perchase ADD CONSTRAINT PK_PRODUCT_PERCHASE PRIMARY KEY (
	perchase_num
);

ALTER TABLE animal_info ADD CONSTRAINT PK_ANIMAL_INFO PRIMARY KEY (
	board_num
);

ALTER TABLE animal_fileupload ADD CONSTRAINT PK_ANIMAL_FILEUPLOAD PRIMARY KEY (
	fno
);

ALTER TABLE animal_fileupload ADD CONSTRAINT FK_Ainfo_TO_Afileupload_1 FOREIGN KEY (
   board_num
)REFERENCES animal_info (
   board_num
)ON DELETE CASCADE;

ALTER TABLE member ADD CONSTRAINT PK_MEMBER PRIMARY KEY (
	id
);

ALTER TABLE used_items ADD CONSTRAINT PK_USED_ITEMS PRIMARY KEY (
	bno
);

ALTER TABLE adoption_review ADD CONSTRAINT PK_ADOPTION_REVIEW PRIMARY KEY (
	bno
);

ALTER TABLE adoption_reply ADD CONSTRAINT PK_ADOPTION_REPLY PRIMARY KEY (
	rno
);

ALTER TABLE commu_fileupload ADD CONSTRAINT PK_COMMU_FILEUPLOAD PRIMARY KEY (
	fno
);

ALTER TABLE qna_fileupload ADD CONSTRAINT PK_QNA_FILEUPLOAD PRIMARY KEY (
	fno
);

ALTER TABLE QNA ADD CONSTRAINT PK_QNA PRIMARY KEY (
	bno
);

ALTER TABLE notice ADD CONSTRAINT PK_NOTICE PRIMARY KEY (
	bno
);

ALTER TABLE FAQ ADD CONSTRAINT PK_FAQ PRIMARY KEY (
	bno
);

ALTER TABLE notice_fileupload ADD CONSTRAINT PK_NOTICE_FILEUPLOAD PRIMARY KEY (
	fno
);

ALTER TABLE faq_fileupload ADD CONSTRAINT PK_FAQ_FILEUPLOAD PRIMARY KEY (
	fno
);

ALTER TABLE used_item_file_upload ADD CONSTRAINT PK_USED_ITEM_FILE_UPLOAD PRIMARY KEY (
	fno
);

ALTER TABLE anymore_fileupload ADD CONSTRAINT PK_ANYMORE_FILEUPLOAD PRIMARY KEY (
	fno
);

ALTER TABLE adopt_fileupload ADD CONSTRAINT PK_ADOPT_FILEUPLOAD PRIMARY KEY (
	fno
);

ALTER TABLE reservation ADD CONSTRAINT FK_member_TO_reservation_1 FOREIGN KEY (
	id
)
REFERENCES member (
	id
)ON DELETE CASCADE;

ALTER TABLE zzim ADD CONSTRAINT FK_member_TO_zzim_1 FOREIGN KEY (
	id
)
REFERENCES member (
	id
)ON DELETE CASCADE;

ALTER TABLE zzim ADD CONSTRAINT FK_animal_info_TO_zzim_1 FOREIGN KEY (
	board_num
)
REFERENCES animal_info (
	board_num
)ON DELETE CASCADE;

ALTER TABLE free_board_reply ADD CONSTRAINT FK_freeboard_TO_reply_1 FOREIGN KEY (
	bno
)
REFERENCES free_board (
	bno
)ON DELETE CASCADE;

ALTER TABLE adopt_reservation ADD CONSTRAINT FK_Ainfo_TO_Areservation_1 FOREIGN KEY (
	board_num
)
REFERENCES animal_info (
	board_num
)ON DELETE CASCADE;

ALTER TABLE free_board ADD CONSTRAINT FK_member_TO_free_board_1 FOREIGN KEY (
	id
)
REFERENCES member (
	id
)ON DELETE CASCADE;

ALTER TABLE product_perchase ADD CONSTRAINT FK_Aproduct_TO_Pperchase_1 FOREIGN KEY (
	product_num
)
REFERENCES anymore_product (
	product_num
)ON DELETE CASCADE;

ALTER TABLE product_perchase ADD CONSTRAINT FK_member_TO_Pperchase_1 FOREIGN KEY (
	id
)
REFERENCES member (
	id
)ON DELETE CASCADE;

ALTER TABLE perchase_info ADD CONSTRAINT FK_Pperchase_TO_Pinfo_1 FOREIGN KEY (
	perchase_num
)
REFERENCES product_perchase (
	perchase_num
)ON DELETE CASCADE;

ALTER TABLE delivery_info ADD CONSTRAINT FK_Perchase_TO_Dinfo_1 FOREIGN KEY (
	perchase_num
)
REFERENCES product_perchase (
	perchase_num
)ON DELETE CASCADE;


ALTER TABLE cart ADD CONSTRAINT FK_member_TO_cart_1 FOREIGN KEY (
	id
)
REFERENCES member (
	id
)ON DELETE CASCADE;

ALTER TABLE cart ADD CONSTRAINT FK_anymore_product_TO_cart_1 FOREIGN KEY (
	product_num
)
REFERENCES anymore_product (
	product_num
)ON DELETE CASCADE;

ALTER TABLE used_items ADD CONSTRAINT FK_member_TO_used_items_1 FOREIGN KEY (
	id
)
REFERENCES member (
	id
)ON DELETE CASCADE;

ALTER TABLE used_items_reply ADD CONSTRAINT FK_Uitems_TO_reply_1 FOREIGN KEY (
	bno
)
REFERENCES used_items (
	bno
)ON DELETE CASCADE;

ALTER TABLE adoption_review ADD CONSTRAINT FK_member_TO_Areview_1 FOREIGN KEY (
	id
)
REFERENCES member (
	id
)ON DELETE CASCADE;

ALTER TABLE adoption_reply ADD CONSTRAINT FK_Areview_TO_Areply_1 FOREIGN KEY (
	bno
)
REFERENCES adoption_review (
	bno
)ON DELETE CASCADE;

ALTER TABLE commu_fileupload ADD CONSTRAINT FK_Fboard_TO_commufileupload_1 FOREIGN KEY (
	bno
)
REFERENCES free_board (
	bno
)ON DELETE CASCADE;

ALTER TABLE QNA_reply ADD CONSTRAINT FK_QNA_TO_QNA_reply_1 FOREIGN KEY (
	bno
)
REFERENCES QNA (
	bno
)ON DELETE CASCADE;

ALTER TABLE QNA_reply ADD CONSTRAINT FK_member_TO_QNA_reply_1 FOREIGN KEY (
	id
)
REFERENCES member (
	id
)ON DELETE CASCADE;

ALTER TABLE qna_fileupload ADD CONSTRAINT FK_QNA_TO_qna_fileupload_1 FOREIGN KEY (
	bno
)
REFERENCES QNA (
	bno
)ON DELETE CASCADE;

ALTER TABLE notice_fileupload ADD CONSTRAINT FK_notice_TO_noticeFile_1 FOREIGN KEY (
	bno
)
REFERENCES notice (
	bno
)ON DELETE CASCADE;

ALTER TABLE faq_fileupload ADD CONSTRAINT FK_FAQ_TO_faq_fileupload_1 FOREIGN KEY (
	bno
)
REFERENCES FAQ (
	bno
)ON DELETE CASCADE;

ALTER TABLE used_item_file_upload ADD CONSTRAINT FK_Uitems_TO_UitemFile_1 FOREIGN KEY (
	bno
)
REFERENCES used_items (
	bno
)ON DELETE CASCADE;

ALTER TABLE anymore_fileupload ADD CONSTRAINT FK_Aproduct_TO_Afileupload_1 FOREIGN KEY (
	product_num
)
REFERENCES anymore_product (
	product_num
)ON DELETE CASCADE;

ALTER TABLE adopt_fileupload ADD CONSTRAINT FK_Areview_TO_Afileupload_1 FOREIGN KEY (
	bno
)
REFERENCES adoption_review (
	bno
)ON DELETE CASCADE;

ALTER TABLE adopt_reservation ADD CONSTRAINT PK_ADOPT_RESERVATION PRIMARY KEY (
	adoptnum
);



-- ������ ������--
create sequence seq_board;
create sequence seq_UIboard;
create sequence seq_ARboard;
create sequence seq_replyFB;
create sequence seq_replyUI;
create sequence seq_replyAR;
create sequence seq_reservation2;
create sequence seq_commuFile;
create sequence seq_adoptFile;
create sequence seq_usedFile;


-- ������ ������ --
create sequence seq_FAQ;
create sequence seq_FAQFile;
create sequence seq_NoticeFile;
create sequence seq_memberNum;
create sequence seq_adopt_reservation;
create sequence seq_reservation;
create sequence seq_protectanimal;
create sequence seq_animal_file; 


-- ������ ������ ---
create sequence seq_qna;
create sequence seq_qna_reply;
create sequence seq_notice;
create sequence seq_adopt_reservation2; 
create sequence seq_QNA_File;


-- ������ ������ --
create sequence seq_product;
create sequence seq_cart;
create sequence seq_perchase;



commit;





